/*
* DejaClick by SmartBear Software.
* Copyright (C) 2006-2022 SmartBear Software.  All Rights Reserved.
*
* The contents of this file are subject to the End User License Agreement.
* Software distributed under the License is distributed on an "AS IS" basis,
* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
* for the specific language governing rights and limitations under the
* License.
*/

'use strict';

/**
 * Preferred width of the change user dialog.
 * @const
 */
var preferredWidth = 450;
/**
 * Preferred height of the change user dialog.
 * @const
 */
var preferredHeight = 400;

if (window.hasOwnProperty('positionDialog')) {
   window.positionDialog(preferredWidth, preferredHeight);
}

window.returnValue = false;

/**
 * Class to encapsulate the functionality of the AlertSite change user dialog.
 * @constructor
 * @param {!DejaClick.Utils} aUtils The background page's utilities object.
 */
DejaClickUi.SelectionPrompt = function (aUtils) {

    this.logger = aUtils.logger;
    this.observerService = aUtils.observerService;
    this.getMessage = aUtils.getMessage;

    this.elements = {
        okButton: $('#okButton'),
        cancelButton: $('#cancelButton'),
        allInputs: $('input'),
        allButtons: $('button'),
        triggerKeyword: $('#triggerKeyword')
    };

    aUtils.localizeTree(document.documentElement, 'deja_');

    this.elements.allInputs.on('input', this.validateNewInput.bind(this));
    this.elements.okButton.button().on('click', this.startSelection.bind(this));
    this.elements.cancelButton.button().on('click', this.cancelSelection.bind(this));
    this.mode = false;

    this.elements.okButton.addClass('ui-state-disabled');

};

DejaClickUi.SelectionPrompt.prototype = {
    /** Constructor for objects with this prototype. */
    constructor: DejaClickUi.SelectionPrompt,

    /**
    * Shut down the dialog in response to the window being closed.
    * Abort any asynchronous activities and dialogs started by this
    * window and release all references to objects external to this
    * dialog.
    * @this {!DejaClickUi.SelectionPrompt}
    */
    close: function () {
        try {
            if (this.hasOwnProperty('elements')) {
                this.elements.allInputs.off('input');
                this.elements.allButtons.off('click').button('destroy');
            }
            
            if (!this.mode){
                this.observerService.notifyLocalObservers('dejaclick:selectionupdatestates', {keyword:'', mode: false});
                this.observerService.notifyLocalObservers('dejaclick:clearnodeselectionclasses');
            }
            this.mode = false;

            delete this.elements;
            delete this.getMessage;
            delete this.logger;
        }catch (ex){
            this.logger.logException(ex);
        }
    },

    /**
    * Update the UI controls in reaction to entering some data in the
    * text fields.
    * @this {!DejaClickUi.SelectionPrompt}
    * @param {!Event} aEvent A jQuery input event on an input element.
    */
    validateNewInput: function (aEvent) {
        try {

            this.elements.triggerKeyword.val().length > 1
            ? this.elements.okButton.removeClass('ui-state-disabled') 
            : this.elements.okButton.addClass('ui-state-disabled');

        } catch (ex) {
            this.logger.logException(ex);
        }
    },

   /**
    * Notify observers to update the node selections states.
    * @this {!DejaClickUi.SelectionPrompt}
    * @param {!Event} aEvent A jQuery click event on the OK button.
    */
    startSelection: function (aEvent) {
        try {
            this.observerService.notifyLocalObservers('dejaclick:selectionupdatestates', {keyword:this.elements.triggerKeyword.val(), mode: true});
            this.mode = true;
            DejaClick.service.__modal.close();
        } catch (ex) {
            this.logger.logException(ex);
        }
    },

    /**
    * Close the window.
    * @this {!DejaClickUi.SelectionPrompt}
    * @param {!Event} aEvent A jQuery click event on the Cancel button.
    */
    cancelSelection: function (aEvent) {
        try {
            this.mode = false;
            DejaClick.service.__modal.close();
        } catch (ex) {
            this.logger.logException(ex);
        }
    },

};

$(function () {
   /**
    * Clean up when the page is unloaded.
    * @param {!Event} A jQuery unload event on the window.
    */
   function unload() {
      try {
         if (DejaClickUi.hasOwnProperty('selectionPrompt')) {
            DejaClickUi.selectionPrompt.close();
            delete DejaClickUi.selectionPrompt;
         }
         $(window).off('unload');
      } catch (ex) {
         DejaClick.utils.logger.logException(ex);
      }
   }

    try {
        DejaClickUi.selectionPrompt = new DejaClickUi.SelectionPrompt(DejaClick.utils);
        $(window).on('unload', unload);
        DejaClick.service.__modal.resizeModal($('body').outerHeight() + 50);
        DejaClick.service.__modal.setTitle('deja_selectionprompt_title');
    } catch (ex) {
        DejaClick.utils.logger.logException(ex);
    }

});
