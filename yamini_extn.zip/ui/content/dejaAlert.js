/* -*- Mode: Javascript; tab-width: 3; indent-tabs-mode: nil; c-basic-offset: 3 -*- */
/*
* DejaClick by SmartBear Software.
* Copyright (C) 2006-2022 SmartBear Software.  All Rights Reserved.
*
* The contents of this file are subject to the End User License Agreement.
* Software distributed under the License is distributed on an "AS IS" basis,
* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
* for the specific language governing rights and limitations under the
* License.
*/


/*global window,DejaClickUi,$,DejaClick,document*/

'use strict';

/**
 * Preferred width of the DejaClick confirm dialog.
 * @const
 */
var preferredWidth = 400;
/**
 * Preferred height of the DejaClick confirm dialog.
 * @const
 */
var preferredHeight = 250;

if (window.hasOwnProperty('positionDialog')) {
   window.positionDialog(preferredWidth, preferredHeight);
}

window.returnValue = {
   button: -1,
   check: false
};


/**
 * Manage the DejaClick Alert dialog window.
 * @constructor
 * @implements {DejaClick.Closable}
 * @param {{
 *    title: string,
 *    message: string,
 * }} aArgs
 *  * @param {!Element} aRootElement The parent element of the page's UI.
 *    This is typically the documentElement.
 * @param {!Window} aWindow The window object.
 * @param {!DejaClick.Utils} aUtils The background page's utilities object.
 */
DejaClickUi.Alert = function (aArgs, aRootElement, aWindow, aUtils) {
   let root;

   this.window = aWindow;
   this.logger = aUtils.logger;

   root = $(aRootElement);

   root.find('#message').html(aArgs.message.replace(/\n/g, '<br>'));
   this.okButton = root.find("#alertOkButton");
   this.okButton.on('click', DejaClick.service.__modal.close);
};

DejaClickUi.Alert.prototype = {
   /** Constructor for objects with this prototype. */
   constructor: DejaClickUi.Alert,

   /**
    * Shut down the dialog, releasing all references to external objects
    * and unregistering all event handlers.
    * @this {!DejaClickUi.Alert}
    */
   close: function () {
      if (this.hasOwnProperty('elements')) {
         this.elements.buttons.off('click').button('destroy');
         this.elements.extraBox.off('change');
      }
      delete this.elements;
      delete this.logger;
      delete this.window;
   },

};

$(function () {
   /**
    * Clean up when the page is unloaded.
    * @param {!Event} A jQuery unload event on the window.
    */
   function unload(aEvent) {
      try {
         if (DejaClickUi.hasOwnProperty('alert')) {
            DejaClickUi.alert.close();
            delete DejaClickUi.alert;
         }
         $(window).off('unload');
      } catch (ex) {
         DejaClick.utils.logger.logException(ex);
      }
   }

   /**
    * Create and initialize the Alert instance once the
    * page is loaded and the dialog arguments are available.
    */
   function initialize() {
      try {
         DejaClickUi.alert = new DejaClickUi.Alert(
            DejaClick.service.__modal.arguments,
            document.documentElement,
            window,
            DejaClick.utils);
         $(window).on('unload', unload);
         DejaClick.service.__modal.resizeModal($('body').outerHeight() + 50);
         DejaClick.service.__modal.setTitle("deja_sidebar_title");

      } catch (ex) {
         DejaClick.utils.logger.logException(ex);
      }
   }

   try {
      if (DejaClick.service.__modal.arguments) {
         initialize();
      } else {
         window.onDialogArguments = initialize;
      }
   } catch (ex) {
      DejaClick.utils.logger.logException(ex);
   }
});
