/* -*- Mode: Javascript; tab-width: 3; indent-tabs-mode: nil; c-basic-offset: 3 -*- */
/*
* DejaClick by SmartBear Software.
* Copyright (C) 2006-2022 SmartBear Software.  All Rights Reserved.
*
* The contents of this file are subject to the End User License Agreement.
* Software distributed under the License is distributed on an "AS IS" basis,
* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
* for the specific language governing rights and limitations under the
* License.
*/


'use strict';

var preferredWidth = 400;

var preferredHeight = 550;

var context;
var prev = {};

window.returnValue = null;

//Ok button

$('#challengeApply').on('click',()=>{
    close(true);
});


$('#challengeCancel').on('click',()=>{
    close(false);
});


//Cancel button
$('#challengeCancel').on('click',()=>{
    close(false);
});
/**
 * 
 * @param {boolean} validate if true we check and either display an error or update the event node
 * @returns if there are errors we return out otherwise the dialog window gets closed
 */
var close = (validate)=>{
    if(validate){
        if(!validateForm()){
            return;
        }
    }
    DejaClick.service.__modal.close();
};

/**
 * If the question or answer textareas are blank return the error function
 * Otherwise the event node challenge question attribute update function is called and returned
 * @returns 
 */
var validateForm = () =>{
    if(document.querySelector('#challengeAnswer').value === '' || document.querySelector('#challengeQuestion').value === ''){
        return highlightError();
    }

    return updateParams();
};

/**
 * If the challenge question or answer fields are blank after clicking the ok button this function will
 * place a red border on the respective text area
 */
var highlightError = ()=>{
    if(document.querySelector("#challengeQuestion").value === ''){
        document.querySelector("#challengeQuestion").style.border = "1px solid red";
    }

    if(document.querySelector("#challengeAnswer").value === ''){
        document.querySelector("#challengeAnswer").style.border = "1px solid red";
    }

    return false;
};

/**
 * This function calls a series of methods to format and update the challenge questions for the event node
 * @returns true
 */
var updateParams = ()=>{
    setChallengeNode(setChallengeObject(getChallengeObject(getChallengeNode(context.context))));
    this.window.returnValue = setValue;
    return true;
};
/**
 * Returns a JSON object in the format of
 * {
 *      challengeQuestion: challenge question textarea value,
 *      challengeAnswer: challenge answer textarea value
 * }
 */
var setValue = () => {
    var challengeQuestion = document.querySelector('#challengeQuestion').value;
    var challengeAnswer = document.querySelector('#challengeAnswer').value;
    return {challengeQuestion,challengeAnswer};
};
/**
 * 
 * @param {xmlnode} the event that we are adding or modifying the  challenge question list
 * @returns the xml node challengeQuestions
 */
var getChallengeNode = (element)=>{
    var parent = DejaClick.script.getChildWithTag(element,'challengeQuestions');
    if( parent == null ){
        DejaClick.script.domTreeInsertNode(element,'challengeQuestions');
        parent = DejaClick.script.getChildWithTag(element,'challengeQuestions');
    }
    return parent;
};

/**
 * 
 * @param {xmlnode} challengeNode 
 * @returns JSON array of challenge question/answer pairs
 */
var getChallengeObject = (challengeNode) =>{
    var challengeQuestions = challengeNode.innerHTML
    return challengeQuestions === '' ? [] : JSON.parse(challengeQuestions);
};
/**
 * 
 * @param {*} challengeObject JSON array of challenge question/answer pairs
 * @returns the updated challengeObject
 */
var setChallengeObject = (challengeObject)=>{
    challengeObject.filter((o,index)=>{
        if(JSON.stringify(o) === JSON.stringify(prev)){
            challengeObject.splice(index,1);
        }
    })
    
    challengeObject.push(setValue());

    return challengeObject;
};
/**
 * 
 * @param {*} challengeObject JSON array of challenge question/answer pairs
 * This function updates the event challenge node questions
 */
var setChallengeNode = (challengeObject) => {
    context.context.querySelector('challengeQuestions').innerHTML = JSON.stringify(challengeObject);
    DejaClick.script.domTreeSetChallenge(context.context, JSON.stringify(challengeObject));
}; 
/**
 * IIFE to set the dialog title, and update the challenge question/answer values if editing
 */
(function(){
    context = DejaClick.service.__modal.arguments;
    DejaClick.service.__modal.setTitle('deja_challenge_title');

    if(context.item !== null){
        prev = getChallengeObject(getChallengeNode(context.context))[context.item];
        document.querySelector('#challengeQuestion').value = prev.challengeQuestion;
        document.querySelector('#challengeAnswer').value = prev.challengeAnswer;
   }    

    if (window.hasOwnProperty('positionDialog')) {
        window.positionDialog(preferredWidth, preferredHeight);
    }
})();