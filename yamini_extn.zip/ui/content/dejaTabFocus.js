/* -*- Mode: Javascript; tab-width: 3; indent-tabs-mode: nil; c-basic-offset: 3 -*- */
/*
* DejaClick by SmartBear Software.
* Copyright (C) 2006-2022 SmartBear Software.  All Rights Reserved.
*
* The contents of this file are subject to the End User License Agreement.
* Software distributed under the License is distributed on an "AS IS" basis,
* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
* for the specific language governing rights and limitations under the
* License.
*/

/*global window,DejaClickUi,$,DejaClick,document,chrome*/

'use strict';

/**
 * Preferred width of the add/edit tabFocus validation dialog.
 * @const
 */
var preferredWidth = 400;
/**
 * Preferred height of the add/edit tabFocus validation dialog.
 * @const
 */
var preferredHeight = 700;

if (window.hasOwnProperty('positionDialog')) {
   window.positionDialog(preferredWidth, preferredHeight);
}

window.returnValue = null;

/**
 * Class to encapsulate the functionality of editing tabFocus validations.
 * @constructor
 * @implements {DejaClick.Closable}
 * @param {{
 *    context: !Element,
 *    item: ?Element,
 *    matchText: (string|undefined),
 *    matchCase:(boolean|undefined),
 *    matchWord:(boolean|undefined),
 *    allowWrap:(boolean|undefined),
 *    fixSpaces:(boolean|undefined),
 *    document:(?Element|undefined)
 * }} aOptions The options passed to the dialog.
 * @param {!Element} aRootElement The parent element of the page's UI.
 *    This is typically the documentElement.
 * @param {!Window} aWindow The window object.
 * @param {!chrome.WindowsApi} aWindowsApi The chrome.windows API.
 * @param {!Object.<string,*>} aConstants The global set of constants
 *    from the background page.
 * @param {!DejaClick.Utils} aUtils The background page's utilities object.
 * @param {!DejaClick.DejaService} aService The DejaClick record/replay service.
 * @param {!DejaClick.Script} aScript The script to which the edited
 *    tabFocus validation applies.
 * @param {function(new:DejaClick.EventRegistration)} AEventRegistration
 *    The event registration constructor.
 * @param {function(
 *    new:DejaClick.DialogWindow,
 *    string,
 *    *,
 *    function(!DejaClick.DialogWindow),
 *    function(*),
 *    !DejaClick.Logger)
 * } ADialogWindow  The DialogWindow constructor.
 * @param {function(
 *    new:DejaClickUi.DisplayLevelSelector,
 *    string,
 *    !Element,
 *    ?function(integer),
 *    {!Object.<string,*>},
 *    !DejaClick.Utils,
 *    !function(new:DejaClick.EventRegistration))
 * } ADisplayLevelSelector The DisplayLevelSelector constructor.
 */
DejaClickUi.TabFocusValidation = function (aOptions , aRootElement,
      aWindow, aWindowsApi, aConstants, aUtils, aService, aScript,
      AEventRegistration, ADialogWindow,
      ADisplayLevelSelector) {

   var root;
   aWindow.returnValue = null;
   this.tabFocusCloseCallback = aOptions.callback ? aOptions.callback : null; 
   this.context = aOptions.context;
   this.item = aOptions.item;
   this.window = aWindow;
   this.windowsApi = aWindowsApi;
   this.constants = aConstants;
   this.logger = aUtils.logger;
   this.service = aService;
   this.script = aScript;
   this.DialogWindow = ADialogWindow;

   this.activatedEvent = new AEventRegistration().enable(true).
      addChromeListener(chrome.tabs.onActivated, this.tabActivated, this);

   this.dialog = null;

   // Find/create UI elements.
   root = $(aRootElement);
   this.elements = {
      title: root.find('title'),
      description: root.find('#TabFocusDescription'),

      matchTitle: root.find('#matchTitle'),
      matchUrl: root.find('#matchUrl'),
      matchIndex: root.find('#matchIndex'),
      
      matchCloseTitle: root.find('#matchCloseTitle'),
      matchCloseUrl: root.find('#matchCloseUrl'),
      matchCloseIndex: root.find('#matchCloseIndex'),

      checkByTitle: root.find('#checkByTitle'),
      checkByIndex: root.find('#checkByIndex'),
      checkByUrl: root.find('#checkByUrl'),

      checkCloseByTitle: root.find('#checkCloseByTitle'),
      checkCloseByIndex: root.find('#checkCloseByIndex'),
      checkCloseByUrl: root.find('#checkCloseByUrl'),

      titleMatchCase: root.find('#titleMatchCase'),
      titleFixSpaces: root.find('#titleFixSpaces'),

      titleMatchOption: root.find('#titleMatchOption'),
      
      urlMatchCase: root.find('#urlMatchCase'),
      urlEncode: root.find('#urlEncode'),
      
      urlMatchOption: root.find('#urlMatchOption'),

      searchSet: root.find('#searchSet'),
      searchAll: root.find('#searchAll'),
      searchOne: root.find('#searchOne'),
      selectDocument: root.find('#tabFocusSelectDocument'),

      tabFocusApply: root.find('#tabFocusApply'),
      tabFocusRemove: root.find('#tabFocusRemove'),
      tabFocusCancel: root.find('#tabFocusCancel'),

      allInputs: root.find('textarea,input,select,a'),
      changeInputs: root.find('#matchTitle,#plainText,#regExp,#searchAll,#searchOne'),
      tabFocusButtons: root.find('button'),
      advancedOnly: root.find('.advancedOnly'),
      validationsOnly: root.find('.validationsOnly'),
      actionTypeFound: root.find('#actionTypeFound'),
      actionTypeNotFound: root.find('#actionTypeNotFound'),

      timeout: root.find('#timeout'),
      retries: root.find('#retries'),

      tabFocusCloseHandler: root.find('#tabFocusCloseHandler')
   };
   aUtils.localizeTree(aRootElement, 'deja_');

   root.find('#tabFocusDisplayLevel').empty();
   this.displayLevel = new ADisplayLevelSelector(
      'x',
      root.find('#tabFocusDisplayLevel')[0],
      this.displayDisplayLevel.bind(this),
      aConstants,
      aUtils,
      AEventRegistration);

   // Display initial values in UI.
   this.item == null ? this.initialState(aUtils) : this.editState(aUtils);

   // Initialize event handlers.
   this.elements.changeInputs.on('change input', this.changeValue.bind(this));
   this.elements.tabFocusButtons.button();
   this.elements.tabFocusApply.button();
   this.elements.selectDocument.button();
   this.elements.tabFocusApply.off('click');
   this.elements.tabFocusApply.on('click', this.tabFocusApply.bind(this, aUtils));
   this.elements.tabFocusRemove.on('click', this.tabFocusRemove.bind(this));
   this.elements.tabFocusCancel.on('click', this.tabFocusCancel.bind(this));
   this.elements.checkByTitle.on('click', this.handleInput.bind(this, "checkByTitle", "matchTitle"));
   this.elements.checkByUrl.on('click', this.handleInput.bind(this, "checkByUrl", "matchUrl"));
   this.elements.checkByIndex.on('click', this.handleInput.bind(this, "checkByIndex", "matchIndex"));
   this.elements.checkCloseByTitle.on('click', this.handleInput.bind(this, "checkCloseByTitle", "matchCloseTitle"));
   this.elements.checkCloseByUrl.on('click', this.handleInput.bind(this, "checkCloseByUrl", "matchCloseUrl"));
   this.elements.checkCloseByIndex.on('click', this.handleInput.bind(this, "checkCloseByIndex", "matchCloseIndex"));
   this.elements.actionTypeFound.on('change', this.handleCloseOption.bind(this));
   this.elements.matchTitle.on('input', this.handleApplyButton.bind(this));
   this.elements.matchUrl.on('input', this.handleApplyButton.bind(this));
   this.elements.matchIndex.on('input', this.handleApplyButton.bind(this));
   this.enableControls();

};

DejaClickUi.TabFocusValidation.prototype = {
   /** Constructor for objects with this prototype. */
   constructor: DejaClickUi.TabFocusValidation,

   /**
    * Shut down the dialog in response to the window being closed.
    * Abort any asynchronous activities and dialogs started by this
    * window and release all references to objects external to this
    * page.
    * @this {!DejaClickUi.TabFocusValidation}
    */
   tabFocusClose: function () {
      if (this.hasOwnProperty('elements')) {
         this.elements.changeInputs.off('change input');
         this.elements.tabFocusButtons.off('click').button('destroy');
      }
      if (this.hasOwnProperty('dialog') && (this.dialog !== null)) {
         this.dialog.close();
         this.dialog = null;
      }
      if (this.hasOwnProperty('displayLevel')) {
         this.displayLevel.close();
      }

      if (this.hasOwnProperty('events')) {
         this.events.close();
      }

      delete this.elements;
      delete this.displayLevel;
      delete this.variableSelector;
      delete this.dialog;
      delete this.helpWindowId;
      delete this.targetDocument;
      delete this.events;
      delete this.DialogWindow;
      delete this.script;
      delete this.service;
      delete this.logger;
      delete this.constants;
      delete this.windowsApi;
      delete this.window;
      delete this.item;
      delete this.context;
   },

   /**
    * Add configuration of tabfocus initial state
    * @this {!DejaClickUi.TabFocusValidation}
    * @param aUtils
    */
   initialState : function(aUtils){
      
      if($('body').is('#tabFocusValidationDialog')){
         DejaClick.service.__modal.setTitle('deja_tabfocus_addTitle');
      } else {
         this.elements.title.text(aUtils.getMessage('deja_tabfocus_addTitle'));
      }
      var contextElements = this.elements;
      this.elements.description.text(aUtils.getMessage('deja_tabfocus_description_add_' + this.context.tagName));
      this.elements.tabFocusCloseHandler.css("display", "none");
      // Match Inputs Elements
      this.elements.checkByUrl.prop('checked', true);
      this.elements.checkByTitle.prop('checked', true);
      this.elements.checkByIndex.prop('checked', true);
      this.elements.matchTitle.show();
      this.elements.matchUrl.show();
      this.elements.matchIndex.show();
     
      // UXM-13446 - Getting recorded URL (Only work with tabfocus and tabclose)
      // this.elements.matchUrl.val(Array.prototype.find.call(
      //    this.context.getElementsByTagName('attrib'), (e)=>e.attributes[0].nodeValue === 'urldocument').textContent);
      
      chrome.tabs.query({active:true}, function(tabs){

         var focusedTab = tabs.filter(tab => {
            return !tab.url.includes(chrome.runtime.getURL(''));
         })
         
         contextElements.matchUrl.val(focusedTab[0].url);
         contextElements.matchTitle.val(focusedTab[0].title);
         contextElements.matchIndex.val(focusedTab[0].index);
         
      })
      this.elements.matchCloseIndex.val(0);

      this.elements.checkCloseByIndex.prop('checked', true);
      this.elements.matchCloseTitle.hide();
      this.elements.matchCloseUrl.hide();
      this.elements.matchCloseIndex.show();

      // Title Options Elements
      this.elements.titleMatchOption.val('1');
      this.elements.titleMatchCase.prop('checked', true);
      this.elements.titleFixSpaces.prop('checked', false);
      
      // Url Options Elements
      this.elements.urlMatchOption.val('1');
      this.elements.urlMatchCase.prop('checked', true);
      this.elements.urlEncode.prop('checked', false);
      
      // Actions Elements
      this.elements.actionTypeFound.val('1');
      this.elements.actionTypeNotFound.val('2');
      
      this.elements.retries.val('1');
      this.elements.timeout.val('2000');

      this.elements.tabFocusRemove.hide();
      this.elements.tabFocusApply.prop("disabled", true);
      this.elements.tabFocusApply.addClass('ui-state-disabled');
   },

   /**
    * Edit configuration of tabfocus state
    * @this {!DejaClickUi.TabFocusValidation}
    * @param aUtils
    */
   editState : function(aUtils){

      if($('body').is('#tabFocusValidationDialog')){
         DejaClick.service.__modal.setTitle('deja_tabfocus_editTitle');
      } else {
         this.elements.title.text(aUtils.getMessage('deja_tabfocus_editTitle'));  
      }
      if(this.context){
         this.elements.description.text(aUtils.getMessage('deja_tabfocus_description_edit_'+this.context.tagName));
      }

      // Match Inputs Elements
      this.handleInputCheckbox('checktitle', 'checkByTitle', 'matchTitle');
      this.handleInputCheckbox('checkurl', 'checkByUrl', 'matchUrl');
      this.handleInputCheckbox('checkindex', 'checkByIndex', 'matchIndex');
      
      this.handleInputCheckbox('checkclosetitle', 'checkCloseByTitle', 'matchCloseTitle');
      this.handleInputCheckbox('checkcloseurl', 'checkCloseByUrl', 'matchCloseUrl');
      this.handleInputCheckbox('checkcloseindex', 'checkCloseByIndex', 'matchCloseIndex');
      
      // Title Options Elements
      this.elements.titleMatchOption.val(this.getParam('titlematchoption'));
      this.elements.titleMatchCase.prop('checked', this.getBoolean(this.getParam('titlematchcase')));
      this.elements.titleFixSpaces.prop('checked', this.getBoolean(this.getParam('titlefixspaces')));
      
      // Url Options Elements
      this.elements.urlMatchOption.val(this.getParam('urlmatchoption'));
      this.elements.urlMatchCase.prop('checked', this.getBoolean(this.getParam('urlmatchcase')));
      this.elements.urlEncode.prop('checked', this.getBoolean(this.getParam('urlencode')));
      
      // Actions Elements
      this.elements.actionTypeFound.val(this.getParam('actionfound'));
      this.getParam('actionfound') == "2" ? this.elements.tabFocusCloseHandler.css("display", "block") : this.elements.tabFocusCloseHandler.css("display", "none");

      this.elements.actionTypeNotFound.val(this.getParam('actionnotfound'));

      this.elements.timeout.val(this.getParam('timeout'));
      this.elements.retries.val(this.getParam('retries'));
      var description = this.script.domTreeGetAttribute(this.context, 'description');
      !!description ? description.includes("Inserted") ? this.elements.tabFocusRemove.hide() : this.elements.tabFocusRemove.show() : this.elements.tabFocusRemove.show();
   },

     /**
    * Apply the changes to this tabFocus validation. Close the window.
    * @this {!DejaClick.TabFocusValidation}
    * @param {Object} aUtils
    */
   tabFocusApply : function (aUtils) {
   
      var parent, win, targets;
      try {
         if (this.item == null) {
            parent = this.script.getChildWithTag(this.context, 'validations');
            if (parent == null) {
               parent = this.script.domTreeInsertNode(this.context,'validations');
            }
            this.item = this.script.domTreeInsertNode(parent, this.isTrigger?'trigger':'validation');
            this.item.setAttribute('type', this.constants.VALIDATION_TYPE_TABFOCUS);
         }
         this.script.renumberElements('validation');
         // Match Input Elements
         this.elements.checkByTitle[0].checked ? this.setParam('matchtitle', this.elements.matchTitle.val()):this.setParam('matchtitle', "");
         this.elements.checkByUrl[0].checked ? this.setParam('matchurl', this.elements.matchUrl.val()):this.setParam('matchurl', "");
         this.elements.checkByIndex[0].checked ? this.setParam('matchindex', this.elements.matchIndex.val()):this.setParam('matchindex', "");

         this.setParam('checktitle', String(this.elements.checkByTitle[0].checked))
         this.setParam('checkurl', String(this.elements.checkByUrl[0].checked))
         this.setParam('checkindex', String(this.elements.checkByIndex[0].checked))

         this.elements.checkCloseByTitle[0].checked ? this.setParam('matchclosetitle', this.elements.matchCloseTitle.val()):this.setParam('matchclosetitle', "");
         this.elements.checkCloseByUrl[0].checked ? this.setParam('matchcloseurl', this.elements.matchCloseUrl.val()):this.setParam('matchcloseurl', "");
         this.elements.checkCloseByIndex[0].checked ? this.setParam('matchcloseindex', this.elements.matchCloseIndex.val()):this.setParam('matchcloseindex', "");

         this.setParam('checkclosetitle', String(this.elements.checkCloseByTitle[0].checked))
         this.setParam('checkcloseurl', String(this.elements.checkCloseByUrl[0].checked))
         this.setParam('checkcloseindex', String(this.elements.checkCloseByIndex[0].checked))
         // Title Options Elements
         this.setParam('titlematchoption', this.elements.titleMatchOption.val());
         this.setParam('titlematchcase', String(this.elements.titleMatchCase.prop('checked')));
         // this.setParam('titleallowwrap', String(this.elements.titleAllowWrap.prop('checked')));
         this.setParam('titlefixspaces', String(this.elements.titleFixSpaces.prop('checked')));

         // Url Options Elements
         this.setParam('urlmatchoption', this.elements.urlMatchOption.val());
         this.setParam('urlmatchcase', String(this.elements.urlMatchCase.prop('checked')));
         this.setParam('urlencode', String(this.elements.urlEncode.prop('checked')));

         // Actions Elements
         this.setParam('actionfound', this.elements.actionTypeFound.val());
         this.setParam('actionnotfound', this.elements.actionTypeNotFound.val());

         this.setParam('timeout', this.elements.timeout.val());
         this.setParam('retries', this.elements.retries.val());

         this.window.returnValue = this.item;
         
         var tabTitle = String(this.elements.matchTitle.val());
         var tabUrl = String(this.elements.matchUrl.val());
         var tabIndex = String(this.elements.matchIndex.val());
         var additional = tabUrl.length !== 0 ? tabUrl : tabTitle.length !== 0 ? tabTitle : "Tab Index: "+tabIndex;
         
         var description = this.script.domTreeGetAttribute(this.context, 'description');
         description = !!description ? description.includes("Inserted") 
         ? aUtils.getMessage("deja_sidebar_InsertTabDescription", [additional]) 
         : description : description;

         !!description ? this.script.domTreeChangeAttribute(this.context, "description", description) : null;
         win = this.window;
         
         if(this.tabFocusCloseCallback){
            this.tabFocusCloseCallback();
         }
         if($('body').is('#tabFocusValidationDialog')){
            this.tabFocusClose();    
            win.close();
         }
         DejaClick.service.__modal.close();
      
      } catch (ex) {
         this.logger.logException(ex);
      }
   },

   /**
    * Remove the validation being edited. Close the window.
    * @this {!DejaClick.TabFocusValidation}
    */
   tabFocusRemove: function () {
      var parent, win;
      try {
         this.window.returnValue = this.item;

         parent = this.item.parentNode;
         this.script.domTreeRemoveNode(this.item);
         if (parent.firstElementChild == null) {
            this.script.domTreeRemoveNode(parent);
         }
         this.script.renumberElements(this.isTrigger?'trigger':'validation');

         win = this.window;
         
         if(this.tabFocusCloseCallback){
            this.tabFocusCloseCallback();
         }
         if($('body').is('#tabFocusValidationDialog')){
            this.tabFocusClose();   
            win.close();
         }
         DejaClick.service.__modal.close();
      } catch (ex) {
         this.logger.logException(ex);
      }
   },

   /**
    * Close the dialog, discarding any changes.
    * @this {!DejaClickUi.TabFocusValidation}
    */
   tabFocusCancel: function () {
      var win;
      try {
         // Close the TabFocusValidation object first to ensure that
         // the help window is closed.
         win = this.window;
         if(this.tabFocusCloseCallback){
            this.tabFocusCloseCallback();
         }
         if($('body').is('#tabFocusValidationDialog')){
            this.tabFocusClose();   
            win.close();
         }
         DejaClick.service.__modal.close();
      } catch (ex) {
         this.logger.logException(ex);
      }
   },

   /**
    * Update the Apply Button disable and enable attribute
    * @this {!DejaClickUi.TabFocusValidation}
    */
   handleApplyButton : function(){
      var validation = true;
      validation = validation && (!this.elements.checkByTitle[0].checked || this.elements.matchTitle.val().length !== 0);
      validation = validation && (!this.elements.checkByIndex[0].checked || this.elements.matchIndex.val().length !== 0);
      validation = validation && (!this.elements.checkByUrl[0].checked || this.elements.matchUrl.val().length !== 0);
      validation = validation && (this.elements.checkByUrl[0].checked || this.elements.checkByIndex[0].checked || this.elements.checkByTitle[0].checked )
      this.elements.tabFocusApply.prop("disabled", !validation)
      !validation ? this.elements.tabFocusApply.addClass('ui-state-disabled') : this.elements.tabFocusApply.removeClass('ui-state-disabled');
   },

   /**
    * Update the UI to show the handle close options
    * @this {!DejaClickUi.TabFocusValidation}
    */
   handleCloseOption : function(){
      this.elements.actionTypeFound.val() !== "2" 
      ? this.elements.tabFocusCloseHandler.css("display", "none")
      : this.elements.tabFocusCloseHandler.css("display", "block");
   },

   /**
    * Update the display based upon the new display level.
    * This is called from the DisplayLevelSelector member (displayLevel).
    * @this {!DejaClickUi.TabFocusValidation}
    * @param {integer} aLevel The new display level.
    */
   displayDisplayLevel: function (aLevel) {
      try {
         
         var isLevel = aLevel >= this.constants.DISPLAYLEVEL_ADVANCED;
         var isTabFocusCloseHandle = this.elements.actionTypeFound.val() == "2";

         this.elements.advancedOnly.toggle(isLevel);
         this.elements.tabFocusCloseHandler.toggle(isLevel && isTabFocusCloseHandle);

      } catch (ex) {
         this.logger.logException(ex);
      }
   },

   /**
    * Enable or disable the controls in this dialog.
    * @this {!DejaClickUi.TabFocusValidation}
    */
   enableControls: function () {
      if (this.dialog == null) {
         this.displayLevel.enableControls(true);
         this.elements.allInputs.removeAttr('disabled');
         this.elements.tabFocusButtons.button('option', 'disabled', false);
    
      } else {
         this.displayLevel.enableControls(false);
         this.elements.allInputs.attr('disabled', 'true');
         this.elements.tabFocusButtons.button('option', 'disabled', true);
      }
   },

   /**
    * Detect when the user change the tab focus when the tab focus dialog
    * window is opend.
    * @this {!DejaClickUi.TabFocusValidation}
    * @param {integer} aEvent {windowId, tabId}.
    */
   tabActivated : function (aEvent) {
      try {
         var tabObj;
         chrome.tabs.query({windowId: aEvent.windowId}, browserWindow => {
            tabObj = browserWindow.find(tabs => {return tabs.id === aEvent.tabId;})
            
            if(this.elements.tabFocusCloseHandler.hasClass("open")){
               this.elements.matchCloseTitle[0].value = tabObj.title;
               this.elements.matchCloseUrl[0].value = this.getUrlSelectValue(tabObj.url);
               this.elements.matchCloseIndex[0].value = tabObj.index;
            }else{
               this.elements.matchTitle[0].value = tabObj.title;
               this.elements.matchUrl[0].value = this.getUrlSelectValue(tabObj.url);
               this.elements.matchIndex[0].value = tabObj.index;
               this.handleApplyButton();
            }

         });
         
      } catch (ex) {
         this.logger.logException(ex);
      }
   },

   // BEGINING OF HELPERS FUNCTIONS

   /**
    * Return the URL string using the option configuration
    * eg. return only the domain if the url option match is going 
    * to check only domain
    * @param {String} url The url from the input
    * @return {String} The transformed url
    */
   getUrlSelectValue : function(url){
      var expresion, urlRegExp, string;
      expresion = /^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
      urlRegExp = url.match(expresion);
      switch(this.elements.urlMatchOption.val()){
         case "1":
            string = url;
            break;
         case "2":
            string = url;
            break;
         case "3": // UXM-13446 - Getting if the tab url schem
            string = urlRegExp[2];
            break;
         case "4": // UXM-13446 - Getting if the tab url
            string = urlRegExp[4];
            break;
         case "5": // UXM-13446 - Getting if the tab url path
            string = urlRegExp[5];
            break;
         case "6": // UXM-13446 - Getting if the tab url schema+domain
            string = urlRegExp[1]+urlRegExp[3];
            break;
         case "7": // UXM-13446 - Getting if the tab url schema+domain+path
            string = urlRegExp[1]+urlRegExp[3]+urlRegExp[5];
            break;
         default:
            string = url;
            break;
      }
      return string;
   },

   /**
    * Get a parameter of the validation being edited.
    * @this {!DejaClickUi.TabFocusValidation}
    * @param {string} aName The name of the parameter to retrieve.
    * @return {?string} The value of the parameter, or null if no such
    *    parameter exists.
    */
   getParam: function (aName) {
      return this.script.domTreeGetValidateParam(this.item, aName);
   },

   /**
    * Set or change the value of a parameter of the validation.
    * @this {!DejaClickUi.TabFocusValidation}
    * @param {string} aName The name of the parameter to set.
    * @param {string} aValue The value of the parameter.
    */
   setParam: function (aName, aValue) {
      this.script.domTreeChangeValidateParam(this.item, aName, aValue);
   },

   /**
    * Helper function to handle the text input check box
    * of the tabfocus
    * @this {!DejaClickUi.TabFocusValidation}
    * @param {String} aParamName The name of the check parameter on XML
    * @param {String} aCheckEle The name of the this.element Check Element
    * @param {String} aMatchEle The name this.element Match Input Element
    */
   handleInputCheckbox : function(aParamName, aCheckEle, aMatchEle){
      var element, checkbox, check, match;
      check = this.getParam(aParamName);
      match = this.getParam(aMatchEle.toLowerCase());
      element = this.elements[aMatchEle];
      checkbox = this.elements[aCheckEle];
      if(check == "true"){
         checkbox.prop("checked", true);
         element.val(match);
      }else{
         checkbox.prop("checked", false);
         element.hide();
      }
   },

   /**
    * Helper function to transform "true", "false", into boolean
    * @this {!DejaClickUi.TabFocusValidation}
    * @param {String} string Could be a string ("true", "false") or a
    * boolean itself, otherwise it will return a undefined value
    */
   getBoolean : function(string){
      switch(string){
         case true:
            return true;
         case false:
            return false;
         case "true":
            return true;
         case "false":
            return false;
         default:
            return undefined;
      }
   },

   /**
    * Change the value of some setting that affects whether another
    * setting is available.
    * @this {!DejaClickUi.TabFocusValidation}
    */
   changeValue : function () {
      try {
         this.enableControls();
      } catch (ex) {
         this.logger.logException(ex);
      }
   },

   /**
    * Helper function for the match inputs if checkbox if checked
    * show the match input text, if not hide it.
    * @this {!DejaClickUi.TabFocusValidation}
    * @param {String} checkbox the checkbox element as string
    * @param {String} input the input element as string
    */
   handleInput : function (checkbox, input){
      this.elements[checkbox][0].checked ? this.elements[input].show() : this.elements[input].hide();
      this.handleApplyButton();
   },

};
   /**
    * Clean up when the page is unloaded.
    */
   function dejaTabFocusunload() {
      try {
         if (DejaClickUi.hasOwnProperty('tabFocusValidation')) {
            DejaClickUi.tabFocusValidation.tabFocusClose();
            delete DejaClickUi.tabFocusValidation;
         }
         $(window).off('unload');
      } catch (ex) {
         DejaClick.utils.logger.logException(ex);
      }
   }

   /**
    * Create and initialize the TabFocusValidation instance once the
    * page is loaded and the dialog arguments are available.
    */
   function dejaTabFocusInitialize(args) {

      // rootelement is validationcontainer if called from sidebar
      var rootElement = args ? $('#tabFocusValidationContainer') : document.documentElement;
      var args = args ? args : DejaClick.service.__modal.arguments;
      try {
         if(DejaClickUi.tabFocusValidation){
            delete DejaClickUi.tabFocusValidation;
         }
         DejaClickUi.tabFocusValidation = new DejaClickUi.TabFocusValidation(
            args,
            rootElement,
            window,
            chrome.windows,
            DejaClick.constants,
            DejaClick.utils,
            DejaClick.service,
            DejaClick.script,
            DejaClick.EventRegistration,
            DejaClick.DialogWindow,
            DejaClickUi.DisplayLevelSelector);

         if($('body').is('#tabFocusValidationDialog')){
               DejaClick.service.__modal.resizeModal($('body').outerHeight() + 50);
         }
         
         return DejaClickUi.tabFocusValidation;

      } catch (ex) {
         DejaClick.utils.logger.logException(ex);
      }
   }
   
   $(function(){
      try {
         if($('body').is('#tabFocusValidationDialog')){
            if (DejaClick.service.__modal.arguments) {
                  dejaTabFocusInitialize();
            } else {
               window.onDialogArguments = dejaTabFocusInitialize;
            }
         }
            
      } catch (ex) {
         DejaClick.utils.logger.logException(ex);
      }
   });
