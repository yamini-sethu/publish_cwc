/* -*- Mode: Javascript; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 3 -*- */
/*
* DejaClick by SmartBear Software.
* Copyright (C) 2006-2022 SmartBear Software.  All Rights Reserved.
*
* The contents of this file are subject to the End User License Agreement.
* Software distributed under the License is distributed on an "AS IS" basis,
* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
* for the specific language governing rights and limitations under the
* License.
*/

'use strict';
   
/**
 *
 * @constructor
 * @implements {DejaClick.Closable}
 * @param {!DejaClick.Logger} aLogger Means of logging messages.
 * @param {!DejaClick.ObserverService} aObserverService Service through which
 * @param {!DejaClick.ObserverService} aEventRegistration For register the observer listener
 */
DejaClick.NodeSelection = function (aLogger, aScript, aObserverService, aEventRegistration) {

    this.m_logger = aLogger;
    this.m_script = aScript;
    this.m_observerService = aObserverService;
    this.m_event_registration = aEventRegistration;

    this.state = {
        // This is the property that will used for branch trigger keyword
        keyword: '',
        // This represent if we are on node selecion mode or not
        mode: false,
        // This our list of node selection for create the new subscript
        nodes: [],

        actionIndex: 0
    }

    this.events = this.m_event_registration.addDejaListener(
        this.m_observerService, 
        'dejaclick:selectionupdatestates', 
        this.updateStates, 
        this);	

};

/** 
 * This prototype wrap the node selection user experience.
 * 
 * It is divide in 2 parts:
 * 
 * 1. The script/state functionalities
 * 
 * This part involve a group of methods and properties, to create,
 * update, modify, delete nodes or elements of the DejaClick XML script.
 * 
 * 2. The UX and visual interactions
 * 
 * This part involve a gruop of methods that modify visual properties on the UI.
 * Also it help to the whole functionality with validations which node can be selected
 * or not.
 * 
 * */

DejaClick.NodeSelection.prototype = {
    /** Constructor for objects with this prototype. */
    constructor: DejaClick.NodeSelection,

    /**
    * @this {!DejaClick.NodeSelection}
    */
    close: function () {
        delete this.m_observerService;
        delete this.m_event_registration;
        delete this.m_script;
        delete this.m_logger;
        delete this.events;
    },
    
    // BEGINING OF THE XML SCRIPTS UPDATES FUNCTIONLAITIES

    /**
     * This function is the root of the XML SCRIPTS UPDATES functions 
     * 
     * It create the subscript, change the states, attach the actions and events,
     * and assign the keyword trigger.
     * 
     * If we want to add more functionalities to this script this should be the start
     * 
     * If we want to create a subscript from the main script in other scope of DejaClick
     * we can use this function but with have to update the states.
     * 
     * @this {!DejaClick.NodeSelection}
     * @param {XML Element} script 
     */ 
    startCreateSubscript : function(script){
        try{
            var subscript = DejaClick.service.domTreeInsertSubscript(script);  
            this.state.mode = false;
            this.state.actionIndex = 0;
            this.createSubscript(0, script, subscript);
            this.insertKeywordTrigger(subscript);
            this.deleteNodeFromMainScript();
            DejaClick.script.renumberElements('subscript');
            DejaClick.script.renumberActions();
            DejaClick.script.renumberEvents();
            this.m_observerService.notifyObservers('dejaclick:refreshscripttabs', {hashkey: "1:script", state:"initial"} );
            this.m_observerService.notifyLocalObservers("dejaclick:updatetreeview");
        }catch(e){
            this.m_logger.logException(e);
        }
    },

    /**
     * This a recursion function it will iterate for each node from 
     * the this.state.node array.
     * 
     * If the node is an action it will jump to the following action.
     * If the node is an event it will jump to the following event.
     * @this {!DejaClick.NodeSelection}
     * @param {Number} iterator The recursion iteration index for the list of nodes
     * @param {XML Element} script The DejaClick whole XML Script
     * @param {XML Element} subscript The Subscript that we are creating
     * @param {XML Element} action The action that we are creating
     * @returns 
     */
    createSubscript : function(iterator, script, subscript, action){
        try{
            // Checking base case rule of this recursive function
            if(this.handleCreateSubscriptBaseCase(iterator, script, subscript, action)) return;
            
            var [seq, type] = this.state.nodes[iterator].hashkey.split(":");

            // Check if the node type is an event or an action
            switch (type){
                case "event":
                    this.handleEventNode(iterator, script, subscript, action, seq);
                    break;
                case "action":
                    this.state.actionIndex = iterator;
                    this.handleActionNode(iterator, script, subscript, action, seq);
                    break;
                default:
                    break;
            }
        }catch(e){
            this.m_logger.logException(e);
        }
    },


    /**
     * As the name state this is a helper function that determine if this acomplish the basecase
     * of the this.createSubscript recursive function. Also it will notify the UI to update the 
     * UI treeview. 
     * @this {!DejaClick.NodeSelection}
     * @param {Number} iterator The recursion iteration index for the list of nodes
     * @param {XML Element} script The DejaClick whole XML Script
     * @param {XML Element} subscript The Subscript that we are creating
     * @param {XML Element} action The action that we are creating
     * @returns 
     */
    handleCreateSubscriptBaseCase : function(iterator, script, subscript, action){
        try{
            var selectedNode = this.state.nodes[iterator];

            if(!selectedNode && !!action){
                subscript.querySelector("actions").appendChild(action);
                return true;
            }else if(!selectedNode){
                return true;
            }
            return false;
        }catch(e){
            this.m_logger.logException(e);
        }
    },

    /** 
     * This is a branch function invokated from the createSubscript function, this should handle
     * when the node is an event
     * @this {!DejaClick.NodeSelection}
     * @param {Number} iterator The recursion iteration index for the list of nodes
     * @param {XML Element} script The DejaClick whole XML Script
     * @param {XML Element} subscript The Subscript that we are creating
     * @param {XML Element} action The action that we are creating
     * @param {String} seq The number of the sequence of the event
     */
    handleEventNode : function(iterator, script, subscript, action, seq){
        try{
            
            var event = script.querySelector("event[seq='"+seq+"']").cloneNode(true);

            // If the first hashkey is an event we might need to create an action
            if(iterator === 0){
                var action = script.querySelector("event[seq='"+seq+"']").parentNode.cloneNode(true);
                var children = action.querySelectorAll("event");
                Array.prototype.map.call(children, node => {
                    action.removeChild(node);
                })
            }

            // Other function is in charge to delete from the main scriptå
            action.appendChild(event);

            // Bump the iterator variable
            iterator++;

            // The recursion continue with a new iterator
            this.createSubscript(iterator, script, subscript, action);

        }catch(e){
            this.m_logger.logException(e);
        }

    },

    /** 
     * This is a branch function invokated from the createSubscript function, this should handle
     * when the node is an action
     * @this {!DejaClick.NodeSelection}
     * @param {Number} iterator The recursion iteration index for the list of nodes
     * @param {XML Element} script The DejaClick whole XML Script
     * @param {XML Element} subscript The Subscript that we are creating
     * @param {XML Element} action The action that we are creating
     * @param {String} seq The number of the sequence of the event
     */
    handleActionNode : function(iterator, script, subscript, action, seq){
        try{

            // If there action object in the argument it should be appended to the subscript/actions
            if(action) subscript.querySelector("actions").appendChild(action);

            // Clone an action from the main script
            var action = script.querySelector("action[seq='"+seq+"']").cloneNode(true);
            
            // How many nodes left on the state.nodes array from the iterator index reference
            var leftNodes = this.state.nodes.slice(iterator).filter((nodes) => nodes.hashkey.includes("event"));

            // If this action is the last node we don't want a lonely action
            if(!leftNodes.length) return;

            // Quantity of events inside of the action object
            var actionNodes = Array.prototype.filter.call(action.childNodes, (child) => child.tagName === "event");
            
            var nextActionIndex = this.state.nodes.slice(iterator).map((nodes, index) => 
                {if(nodes.hashkey.includes("action") && index != 0){return index}}
            ).find((index) => !!index);

            // UXM-11950 substraction of the left nodes and action nodes
            var resultNodes = leftNodes.length-actionNodes.length;

            // Update the iterator
            if(resultNodes > 0){
                iterator = this.state.actionIndex+nextActionIndex;
            }else if(resultNodes == 0){
                iterator = this.state.nodes.length;
            }else{
                iterator = this.state.nodes.length;
                for(var i = 0; i<resultNodes*-1; i++){
                    action.removeChild(actionNodes[actionNodes.length-1-i]);
                }
            }

            subscript.querySelector("actions").appendChild(action);
            this.m_script.renumberElements('event', action);
            this.createSubscript(iterator, script, subscript, action);

        }catch(e){
            this.m_logger.logException(e);
        }
    },

    /**
     * This function will update the subscript level trigger property
     * with the keyword properties assigned previously in the this.state object
     * @this {!DejaClick.NodeSelection}
     * @param {XML Element} subscript The Subscript that we are creating
     */
    insertKeywordTrigger: function(subscript){
        try{
            var script = this.m_script;
            var parent = script.domTreeInsertNode(subscript, 'triggers');
            var item = script.domTreeInsertNode(parent, 'trigger');
            item.setAttribute('type', '1');
            script.domTreeChangeValidateParam(item, 'matchtext', this.state.keyword);
            script.domTreeChangeValidateParam(item, 'matchtype', '1');
            script.domTreeChangeValidateParam(item, 'matchword','true');
            script.domTreeChangeValidateParam(item, 'allowwrap','true');
            script.domTreeChangeValidateParam(item, 'fixspaces','true');
            script.domTreeChangeValidateParam(item, 'actiontype', 'true');
            script.domTreeChangeValidateParam(item, 'actiontype', 'true');
            script.domTreeChangeValidateParam(item, 'searchtype','1');
        }catch(e){
            this.m_logger.logException(e);
        }
    },
    
    /**
     * This function will sort the order of the nodes that should be deleted and will inform the UI
     */
    deleteNodeFromMainScript : function(){
        try{
            var nodes = this.state.nodes.reverse();
            this.m_observerService.notifyLocalObservers("dejaclick:deletenodes", {nodes:nodes});
        }catch(e){
            this.m_logger.logException(e);
        }
    },

    /**
     * This function handle the observer callback, 
     * basically is use to update/reset 
     * DejaClick.utils.nodeSelection.state properties.
     * @this {!DejaClick.NodeSelection}
     * @param {*} data {mode, keyword, nodes}
     */
    updateStates: function(data){
        try{
            this.state.mode = data.mode ? data.mode : false;

            // If data.mode is true we assign new variable to data.keyword property, if not we reset it
            this.state.keyword = data.mode ? data.keyword : '';
    
            // If data.nodes is not defined this mean that we don't change this property
            this.state.nodes = !data.nodes ? this.state.nodes : data.nodes;
        }catch(e){
            this.m_logger.logException(e);
        }
    },


    // BEGINING OF THE UI AND VISUAL UPDATE FUNCTIONALITIES

    /**
     * this function wrap all the functionality to store the new data into
     * the state.node array. 1. It will select the node hashkey, the previousHashkey and next node hashkey
     * also it will validate if those hashkey are correct and it will store in a precise position on the array
     * also it will notify to the UI update some style properties
     * @param {XML Element} target The XML Element target for the node selection
     * @returns 
     */
    selectNode : function(target){
        try{
            var hashkeys = this.getSelectNodeHashkey(target);

            switch (this.validateSelectedNode(hashkeys.hashkey)){
                case 0: this.state.nodes.unshift(hashkeys); break;
                case 1: this.state.nodes.push(hashkeys); break;
                default: return;
            }

            this.m_observerService.notifyLocalObservers("dejaclick:applynodeselectionclasses", {hashkeys:hashkeys});
            return;
        }catch(e){
            this.m_logger.logException(e);
        }
    },

    /**
     * This is a validation function that also determine if the data should be 
     * unshift (place at the begining of the state.node array) or
     * push (place at the end of the state.node array)
     * @this {!DejaClick.NodeSelection}
     * @param {String} hashkey DejaClick standard hashkey
     * @returns 
     */
    validateSelectedNode : function(hashkey){
        try{

            if(hashkey.includes("subscript")) return 2;

            var selectedNodes = this.state.nodes;
            if(selectedNodes.length === 0) {return 1};
            if(selectedNodes[0].previousHashkey === hashkey) {return 0};
            if(selectedNodes[selectedNodes.length-1].nextHashkey === hashkey) {return 1};

            return 2;

        }catch(e){
            this.m_logger.logException(e);
        }
    },

    /**
     * From the target DOM element of the XML Script 
     * @this {!DejaClick.NodeSelection}
     * @param {XML Element} target XML Element from the XML DejaClick script
     * @returns It will return the hashkey of the element
     * the previous element hashkey and the next element 
     * hashkey used for validations and UI visual updates.
     */
    getSelectNodeHashkey : function(target){
        try{
            var hashkey = target.parentNode.getAttribute("hashkey");
            var nextHashkey = this.getNextSelectNodeHashkey(target, hashkey); 
            var previousHashkey = this.getPreviousSelectNodeHashkey(target, hashkey);
            return {hashkey: hashkey, nextHashkey: nextHashkey, previousHashkey: previousHashkey};
        }catch(e){
            this.m_logger.logException(e);
        }
    },

    /**
     * This is basically a search function that will return the hashkey of the next
     * standard DejaClick hashkey found on the XML script with a given XML element
     * @this {!DejaClick.NodeSelection}
     * @param {XML Element} target XML Element from the XML DejaClick script
     * @param {String} hashkey DejaClick standard hashkey
     * @returns Could return the next action hashkey or the next event hashkey
     */
    getNextSelectNodeHashkey : function(target, hashkey){
        try{
            if(hashkey.includes("subscript")) return; 

            if(hashkey.includes("event")){ 

                var next = target.parentNode.nextSibling !== null 
                    ? target.parentNode.nextSibling.getAttribute("hashkey") 
                    : null;

                // If next node is null can be that we reach an action element
                next = next === null 
                    ? target.parentNode.parentNode.parentNode.nextSibling !== null 
                        ? target.parentNode.parentNode.parentNode.nextSibling.getAttribute("hashkey") : next 
                    : next;
            }else{
                var next = target.parentNode.children[2].children[0].getAttribute("hashkey");
            }

            next = next != null 
                ? next.split(":")[0] === "1" 
                    ? null : next 
                : null;

            return next;
        }catch(e){
            this.m_logger.logException(e);
        }
    },

    /**
     * This is basically a search function that will return the hashkey of the previous
     * standard DejaClick hashkey found on the XML script with a given XML element
     * @this {!DejaClick.NodeSelection}
     * @param {XML Element} target XML Element from the XML DejaClick script
     * @param {String} hashkey DejaClick standard hashkey
     * @returns Could return the previous action hashkey or the previous event hashkey
     */
    getPreviousSelectNodeHashkey : function(target, hashkey){
        try{
            if(hashkey.includes("subscript")) return;

            if(hashkey.includes("event")){
                var next = target.parentNode.previousSibling !== null 
                    ? target.parentNode.previousSibling.getAttribute("hashkey") 
                    : null;

                // If next node is null can be that we reach an action element
                next = next === null 
                    ? target.parentNode.parentNode.parentNode !== null 
                        ? target.parentNode.parentNode.parentNode.getAttribute("hashkey") : next 
                    : next;

            }else{
                var element = target.parentNode.previousSibling !== null 
                    ? target.parentNode.previousSibling.children[2] 
                    : null;

                var next = target.parentNode.previousSibling !== null 
                    ? element.children[element.children.length-1].getAttribute("hashkey") 
                    : null;
            }

            next = next != null 
                ? next.split(":")[0] === "1" 
                    ? null : next 
                : null;

            return next;
        }catch(e){
            this.m_logger.logException(e);
        }
    },

};
