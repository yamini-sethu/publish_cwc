DejaClick.CookieAttribute = function(aLogger, aObserverService, aEventRegistration) {

    this.m_logger = aLogger;
    this.m_observerService = aObserverService;
    this.m_event_registration = aEventRegistration;

    this.events = this.m_event_registration.addDejaListener(
        this.m_observerService, 
        'dejaclick:deletecookies', 
        this.deleteCookieAttrib, 
        this
    );	

};


DejaClick.CookieAttribute.prototype = {
    constructor: DejaClick.CookieAttribute,

    deleteCookieAttrib : function(){
        let script = DejaClick.getScript()
        let cookieNode = script.m_scriptElement.querySelector('attrib[name^="persistantCookies"');
        script.removePersistantCookies(cookieNode);
    }
}

