var challengeModule = function(){
    /**
     * 
     * @param {object} aEventInfo 
     * @returns true if there are challenge question/answer pairs for the step
     */
    var hasChallengeQuestion = (aEventInfo)=>{
        if(typeof aEventInfo.attributes.challengeQuestion !== 'undefined'){
            var questionList = JSON.parse(aEventInfo.attributes.challengeQuestion);
            return questionList.length > 0;
        }
        return false;
    };
 
    /**
     * 
     * @param {Object} aEventInfo 
     * @param {*} target element to change the value of if the challenge question is located
     * @param {*} timeout max time available to find the challenge question
     * @param {*} i time elapsed to find the challenge question
     * @returns either a recursive call to itself to retry (page may not have fully loaded), true if found, 
     * false if the question was not found
     */
    var challengeQuestion = async function(aEventInfo,target,timeout,i){
        var questionList = JSON.parse(aEventInfo.attributes.challengeQuestion);   
        var reference = document.body.textContent.split('\n').join(' ').split('\t').join(' ').toLowerCase();
        var found = false;
        questionList.map((o)=>{
            if(reference.indexOf(o.challengeQuestion.toLowerCase()) > -1){
                target.value = o.challengeAnswer;
                found = true;
            }
        });
 
        await new Promise(r=> setTimeout(r,100));
 
       if(!!found){
          return found;
       }
 
      if(i>Number(timeout)/100){
           return found;
        }
 
        return await challengeQuestion(aEventInfo, target, timeout, i+1);
    }

    return {
        hasChallengeQuestion:hasChallengeQuestion,
        challengeQuestion:challengeQuestion
    }
}();